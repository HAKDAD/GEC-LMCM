
from flask import Flask, render_template, request, redirect, url_for, flash
from twilio.rest import Client
from celery import Celery
import schedule
import time
from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import threading  # Import the threading module
import secrets


from flask import jsonify

app = Flask(__name__, static_url_path='/static')

app.secret_key = secrets.token_hex(16)  # Generates a 32-character (16 bytes) hex key

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://hacker:hacker@localhost/teacher_notification_db'
db = SQLAlchemy(app)
migrate = Migrate(app, db)


#MGK19ZM9CU2H859YBKAYW2EE



# Flag to ensure the code is executed only once


is_first_request = True

# Twilio configuration (replace with your own credentials)
TWILIO_ACCOUNT_SID = 'AC81266eefc7cc9b7797a8bd0231fbf1bd'
TWILIO_AUTH_TOKEN = '6db9cec445026f56457a87d625d65078'
TWILIO_PHONE_NUMBER = '+12055063595'


# Initialize Celery
app.config['CELERY_BROKER_URL'] = 'redis://localhost:6379/0'  # Use Redis as the message broker
app.config['CELERY_RESULT_BACKEND'] = 'redis://localhost:6379/0'  # Use Redis as the result backend
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update(app.config)

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

class Teacher(db.Model):
    __tablename__ = 'teacher'  # Explicitly set the table name to 'teacher'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    phone_number = db.Column(db.String(20), nullable=False)
    classes = db.relationship('Class', backref='teacher', lazy=True)


class Class(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    teacher_id = db.Column(db.Integer, db.ForeignKey('teacher.id'), nullable=False)
    class_name = db.Column(db.String(255), nullable=False)
    class_time = db.Column(db.Time, nullable=False)


# Initialize MySQL

@app.route('/')
def home():
    # Replace with code to fetch and display data from the database
    return render_template('base.html')
    
@app.route('/add_teacher', methods=['GET', 'POST'])
def add_teacher():
    if request.method == 'POST':
        name = request.form['name']
        phone_number = request.form['phone_number']
        teacher = Teacher(name=name, phone_number=phone_number)
        db.session.add(teacher)
        db.session.commit()

        return redirect(url_for('add_teacher'))
    return render_template('add_teacher.html')


################################################################
@app.route('/add_class', methods=['GET', 'POST'])
def add_class():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        class_name = request.form['class_name']
        class_time = request.form['class_time']
        
        # Verify that the selected teacher_id exists in the teacher table
        existing_teacher = Teacher.query.get(teacher_id)
        
        if existing_teacher:
            class_data = Class(teacher_id=teacher_id, class_name=class_name, class_time=class_time)
            db.session.add(class_data)
            db.session.commit()
            return redirect(url_for('add_class'))
        else:
            # Handle the case where the selected teacher does not exist
            flash('Invalid teacher selected. Please choose a valid teacher.')
    
    teachers = Teacher.query.all()  # Retrieve a list of all teachers
    return render_template('add_class.html', teachers=teachers)

################################################################
@celery.task
def send_notification(teacher_id, class_name):
    with app.app_context():
        session = db.session
        teacher = session.get(Teacher, teacher_id)  # Use Session.get() to query the database
        if teacher:
            message = client.messages.create(
                body=f"Your {class_name} class is in 10 minutes.",
                from_=TWILIO_PHONE_NUMBER,
                to=teacher.phone_number  # Access the teacher's attributes from the database record
            )
    print("sent {teacher_id}")


def check_upcoming_classes():
    now = datetime.now()
    classes = Class.query.all()
    for class_data in classes:
        class_time = class_data.class_time
        time_until_class = class_time - now


        if timedelta(0) <= time_until_class <= timedelta(minutes=10):
        	
            send_notification(class_data.teacher_id, class_data.class_name)

# Schedule sending notifications every minute to check for upcoming classes
def run_check_upcoming_classes_continuously():
    with app.app_context():
        while True:
            schedule.run_pending()
            time.sleep(1)  # Sleep for 1 second to avoid high CPU usage
            now = datetime.now()
            classes = Class.query.all()
            for class_data in classes:
                class_time = class_data.class_time
                # Combine the date part of `now` with the time part of `class_time`
                class_datetime = datetime.combine(now.date(), class_time)
                time_until_class = class_datetime - now

                if timedelta(0) <= time_until_class <= timedelta(minutes=10):
                    send_notification(class_data.teacher_id, class_data.class_name)
               
########################################################



# Route for editing or deleting a class
@app.route('/edit_or_delete_class', methods=['GET', 'POST'])
def edit_or_delete_class():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        class_id = request.form['class_id']
        
        if 'edit' in request.form:
            # Redirect to the edit_class route with the selected class_id
            return redirect(url_for('edit_class', class_id=class_id))
        elif 'delete' in request.form:
            # Delete the selected class (you need to implement this logic)
            class_data = Class.query.get(class_id)
            if class_data:
                db.session.delete(class_data)
                db.session.commit()
            return redirect(url_for('edit_or_delete_class'))  # Redirect to the same page

    teachers = Teacher.query.all()
    classes = Class.query.all()
    return render_template('edit_or_delete_class.html', teachers=teachers, classes=classes)

# Route for editing or deleting a teacher
@app.route('/edit_or_delete_teacher', methods=['GET', 'POST'])
def edit_or_delete_teacher():
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        
        if 'edit' in request.form:
            # Redirect to the edit_teacher route with the selected teacher_id
            return redirect(url_for('edit_teacher', teacher_id=teacher_id))
        elif 'delete' in request.form:
            # Delete the selected teacher (you need to implement this logic)
            teacher = Teacher.query.get(teacher_id)
            if teacher:
                db.session.delete(teacher)
                db.session.commit()
            return redirect(url_for('edit_or_delete_teacher'))  # Redirect to the same page

    teachers = Teacher.query.all()
    return render_template('edit_or_delete_teacher.html', teachers=teachers)


@app.route('/edit_teacher/<int:teacher_id>', methods=['GET', 'POST'])
def edit_teacher(teacher_id):
    teacher = Teacher.query.get(teacher_id)
    
    if request.method == 'POST':
        name = request.form['name']
        phone_number = request.form['phone_number']
        teacher.name = name
        teacher.phone_number = phone_number
        db.session.commit()
        flash('Teacher details updated successfully')
        return redirect(url_for('edit_teacher', teacher_id=teacher_id))
    
    return render_template('edit_teacher.html', teacher=teacher)


@app.route('/delete_teacher/<int:teacher_id>', methods=['POST'])
def delete_teacher(teacher_id):
    teacher = Teacher.query.get(teacher_id)
    if teacher:
        db.session.delete(teacher)
        db.session.commit()
        flash('Teacher deleted successfully')
    return redirect(url_for('add_teacher'))

@app.route('/edit_class/<int:class_id>', methods=['GET', 'POST'])
def edit_class(class_id):
    class_data = Class.query.get(class_id)
    
    if request.method == 'POST':
        teacher_id = request.form['teacher_id']
        class_time = request.form['class_time']
        
        # Verify that the selected teacher_id exists in the teacher table
        existing_teacher = Teacher.query.get(teacher_id)
        
        if existing_teacher:
            class_data.teacher_id = teacher_id
            class_data.class_time = class_time
            db.session.commit()
            flash('Class details updated successfully')
            return redirect(url_for('edit_class', class_id=class_id))
        else:
            flash('Invalid teacher selected. Please choose a valid teacher.')
    
    teachers = Teacher.query.all()  # Retrieve a list of all teachers
    return render_template('edit_class.html', class_data=class_data, teachers=teachers)

@app.route('/delete_class/<int:class_id>', methods=['POST'])
def delete_class(class_id):
    class_data = Class.query.get(class_id)
    if class_data:
        db.session.delete(class_data)
        db.session.commit()
        flash('Class deleted successfully')
    return redirect(url_for('add_class'))


######################################################################################

@app.route('/get_classes/<int:teacher_id>')
def get_classes(teacher_id):
    classes = Class.query.filter_by(teacher_id=teacher_id).all()
    classes_data = [{'id': Class.id, 'class_name': Class.class_name} for Class in classes]
    return jsonify({'classes': classes_data})

    
######################################################################################


if __name__ == '__main__':
    # Start a timer that runs the check_upcoming_classes function continuously
    timer_thread = threading.Thread(target=run_check_upcoming_classes_continuously)
    timer_thread.daemon = True  # Run the thread as a daemon to allow the main program to exit
    timer_thread.start()

    app.run(debug=True)
